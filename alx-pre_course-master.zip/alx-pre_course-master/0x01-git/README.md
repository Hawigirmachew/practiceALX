my first readme iside 0x01-git
