Pointers to pointers and multideminsional arrays
