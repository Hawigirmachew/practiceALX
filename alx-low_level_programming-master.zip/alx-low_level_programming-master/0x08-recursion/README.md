REcursion function in C
