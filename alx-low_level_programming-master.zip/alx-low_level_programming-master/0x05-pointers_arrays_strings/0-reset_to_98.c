#include "main.h"
#include <stdio.h>
/**
 * reset_to_98 - changes the value of given variable to n
 * @n: A pointer points to an integer
 * Return - Always 0
 */
void reset_to_98(int *n)
{
	*n = 98;
}
