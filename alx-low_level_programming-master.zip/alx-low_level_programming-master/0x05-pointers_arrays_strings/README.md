Pointers, Arrays and Strings
