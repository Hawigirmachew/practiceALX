#ifndef MAIN_H
#define MAIN_H

#include <stdio.h>

void positive_or_negative(int n);
int largest_number(int a, int b, int c);
void print_remianing_days(int month, int day, int year);
int convert_days(int month, int day);

#endif
