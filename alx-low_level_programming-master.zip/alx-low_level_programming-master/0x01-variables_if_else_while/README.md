Variables, if...else and while loop
