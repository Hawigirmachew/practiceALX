#include "main.h"
/**
 * add - adds two number
 * @a: the first number
 * @b: the second number
 * Return: sum
 */
int add(int a, int b)
{
	return (a + b);
}
