#include <stdio.h>

/**
 *main - Entry point
 *
 *Return: Always 0 (success)
 */
int main(void)
{
  puts("\"Programming is like building a multilingual puzzel");
  return (0);
}