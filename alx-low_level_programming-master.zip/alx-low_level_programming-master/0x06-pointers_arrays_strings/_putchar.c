#include <unistd.h>
/**
 * _putchar - used to prit char
 * @n: takes an char
 * Return: integer
 */
int _putchar(char n)
{
	return (write(1, &c, 1));
}

